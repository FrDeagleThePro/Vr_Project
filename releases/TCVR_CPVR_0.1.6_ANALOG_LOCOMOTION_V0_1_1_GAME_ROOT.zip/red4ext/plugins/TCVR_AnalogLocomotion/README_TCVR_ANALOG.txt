TCVR ANALOG LOCOMOTION v0.1.1
Target: CyberpunkVRPort 0.1.6 (01/09/2026)

BUT
---
Restaure la magnitude analogique progressive du stick gauche, comme avant le
changement de locomotion discrete introduit dans CPVR 0.1.2.

VERIFIE SUR CPVR 0.1.6
----------------------
Le code de release CPVR 0.1.6 exporte toujours :
  CyberpunkVR_MoveTiers = 1

Quand cette valeur vaut 1, CPVR force une magnitude de deplacement fixe apres
la deadzone. Quand elle vaut 0, CPVR conserve la magnitude analogique du stick.

TCVR_AnalogLocomotion est un plugin RED4ext SEPARE qui retrouve cet export en
memoire et le maintient a 0.

RESULTAT
--------
- faible inclinaison du stick = faible vitesse ;
- inclinaison moyenne = vitesse intermediaire ;
- forte inclinaison = vitesse plus elevee ;
- le sprint CPVR 0.1.6 reste gere par CPVR ;
- les vehicules restent geres normalement par CPVR ;
- aucun changement n'est apporte au clic L3 ;
- aucun changement n'est apporte aux mappings Y + stick droit.

IMPORTANT : AUCUN FICHIER CPVR N'EST REMPLACE
---------------------------------------------
Ce ZIP ajoute seulement :
red4ext\plugins\TCVR_AnalogLocomotion\TCVR_AnalogLocomotion.dll

Il ne modifie ni ne remplace aucun fichier de CyberpunkVRPort 0.1.6.

INSTALLATION
------------
Extraire le ZIP a la RACINE de Cyberpunk 2077, la ou se trouvent bin, r6,
red4ext, archive, etc.

DESINSTALLATION
---------------
Supprimer uniquement :
red4ext\plugins\TCVR_AnalogLocomotion\

TEST
----
A pied, pousser progressivement le stick gauche a environ 25 %, 50 %, 75 % puis
presque 100 %. La vitesse doit varier progressivement au lieu d'etre fixe des
que le stick depasse la deadzone.

NOTES
-----
- Le probleme materiel L3 du controleur n'est pas traite ici et n'a pas besoin
  de l'etre pour cette fonction.
- Premiere version 0.1.6 volontairement minimale : pas de deadzone custom, pas
  de courbe custom, pas de remapping supplementaire.
